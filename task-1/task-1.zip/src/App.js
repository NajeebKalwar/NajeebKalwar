
import React from 'react'
import Ui from './Components/ui';

function App() {
  return (
    <>
    <Ui/>
    </>
  )
}

export default App




